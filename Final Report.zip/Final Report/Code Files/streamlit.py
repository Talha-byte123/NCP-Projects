import streamlit as st
import imutils
import numpy as np
import cv2
import matplotlib.pyplot as plt
from base64 import b64decode
from PIL import Image
import requests

logo_path = "logo3.jpg"
logo_path2= "logo2.jpg"
col1, col2, col3 = st.columns([1, 2, 1])  # Adjust the width ratio as needed
with col1:
    st.image(logo_path, width=120)  # Adjust the width to resize the image

# Place text in column 2
with col2:
    st.markdown("<h1 style='text-align: center;'>VISION AR</h1>", unsafe_allow_html=True)
    # You can customize the text and its style (e.g., font size, alignment) here

# Place the second image in column 3
with col3:
    st.image(logo_path2, width=150)  # Adjust the width to resize the image
def download_model():  
    prototxt_url = "https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt"
    caffemodel_url = "https://raw.githubusercontent.com/opencv/opencv_3rdparty/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel"

    prototxt_path = "deploy.prototxt"
    caffemodel_path = "res10_300x300_ssd_iter_140000.caffemodel"
    net = cv2.dnn.readNetFromCaffe(prototxt_path, caffemodel_path)

    image = imutils.resize(image, width=400)
    blob = cv2.dnn.blobFromImage(cv2.resize(image, (300, 300)), 1.0, (300, 300), (104.0, 177.0, 123.0))

    print("[INFO] computing object detections...")
    net.setInput(blob)
    detections = net.forward()
    print(detections.shape)

picture = st.camera_input("Take a picture")
if picture:
    
    image = Image.open(picture).convert("RGB")
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    st.image(image, channels="BGR")



st.markdown("""
    <style>
    .footer {
        background-color: transparent;
        color: white;  /* Change text color to white */
        text-align: center;
        padding: 10px;
        margin-top: 2px;
    }
    </style>
    <div class="footer">
        <p>Copyright@ARVision</p>
    </div>
    """, unsafe_allow_html=True)
